import sys
import re
from PyQt5.QtWidgets import (QApplication, QMainWindow, QTextEdit, QTabWidget, 
                            QFileDialog, QAction, QDialog, QVBoxLayout, 
                            QHBoxLayout, QLabel, QLineEdit, QPushButton, 
                            QMessageBox, QToolBar, QStatusBar)
from PyQt5.QtGui import (QSyntaxHighlighter, QTextCharFormat, QTextCursor, 
                         QFont, QColor, QKeySequence, QIcon, QPalette)
from PyQt5.QtCore import Qt, QRegExp

class PythonHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.highlightingRules = []
        
        # Ключевые слова Python
        keywords = [
            'and', 'as', 'assert', 'break', 'class', 'continue', 'def', 'del',
            'elif', 'else', 'except', 'False', 'finally', 'for', 'from', 'global',
            'if', 'import', 'in', 'is', 'lambda', 'None', 'nonlocal', 'not', 'or',
            'pass', 'raise', 'return', 'True', 'try', 'while', 'with', 'yield'
        ]
        
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor(200, 120, 50))
        keyword_format.setFontWeight(QFont.Bold)
        
        for word in keywords:
            pattern = r'\b{}\b'.format(word)
            self.highlightingRules.append((QRegExp(pattern), keyword_format))
        
        # Строки
        string_format = QTextCharFormat()
        string_format.setForeground(QColor(20, 110, 100))
        self.highlightingRules.append((QRegExp(r'"[^"\\]*(\\.[^"\\]*)*"'), string_format))
        self.highlightingRules.append((QRegExp(r"'[^'\\]*(\\.[^'\\]*)*'"), string_format))
        
        # Комментарии
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor(100, 100, 100))
        comment_format.setFontItalic(True)
        self.highlightingRules.append((QRegExp(r'#[^\n]*'), comment_format))
        
        # Числа
        number_format = QTextCharFormat()
        number_format.setForeground(QColor(150, 80, 180))
        self.highlightingRules.append((QRegExp(r'\b[0-9]+\b'), number_format))
        
        # Функции
        function_format = QTextCharFormat()
        function_format.setForeground(QColor(30, 120, 200))
        function_format.setFontWeight(QFont.Bold)
        self.highlightingRules.append((QRegExp(r'\b[A-Za-z0-9_]+(?=\()'), function_format))

    def highlightBlock(self, text):
        for pattern, format in self.highlightingRules:
            expression = QRegExp(pattern)
            index = expression.indexIn(text)
            while index >= 0:
                length = expression.matchedLength()
                self.setFormat(index, length, format)
                index = expression.indexIn(text, index + length)
        
        self.setCurrentBlockState(0)

class FindReplaceDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Найти и заменить")
        self.setModal(False)
        
        layout = QVBoxLayout()
        
        # Поля ввода
        find_layout = QHBoxLayout()
        find_layout.addWidget(QLabel("Найти:"))
        self.find_field = QLineEdit()
        find_layout.addWidget(self.find_field)
        layout.addLayout(find_layout)
        
        replace_layout = QHBoxLayout()
        replace_layout.addWidget(QLabel("Заменить на:"))
        self.replace_field = QLineEdit()
        replace_layout.addWidget(self.replace_field)
        layout.addLayout(replace_layout)
        
        # Кнопки
        buttons_layout = QHBoxLayout()
        
        self.find_button = QPushButton("Найти")
        self.find_button.clicked.connect(self.find_text)
        buttons_layout.addWidget(self.find_button)
        
        self.replace_button = QPushButton("Заменить")
        self.replace_button.clicked.connect(self.replace_text)
        buttons_layout.addWidget(self.replace_button)
        
        self.replace_all_button = QPushButton("Заменить все")
        self.replace_all_button.clicked.connect(self.replace_all)
        buttons_layout.addWidget(self.replace_all_button)
        
        self.close_button = QPushButton("Закрыть")
        self.close_button.clicked.connect(self.close)
        buttons_layout.addWidget(self.close_button)
        
        layout.addLayout(buttons_layout)
        self.setLayout(layout)
    
    def find_text(self):
        text = self.find_field.text()
        if text:
            editor = self.parent().current_editor()
            if editor:
                found = editor.find(text)
                if not found:
                    QMessageBox.information(self, "Поиск", "Текст не найден")
    
    def replace_text(self):
        find_text = self.find_field.text()
        replace_text = self.replace_field.text()
        if find_text:
            editor = self.parent().current_editor()
            if editor:
                cursor = editor.textCursor()
                if cursor.selectedText() == find_text:
                    cursor.insertText(replace_text)
                self.find_text()
    
    def replace_all(self):
        find_text = self.find_field.text()
        replace_text = self.replace_field.text()
        if find_text:
            editor = self.parent().current_editor()
            if editor:
                editor.moveCursor(QTextCursor.Start)
                editor.textCursor().beginEditBlock()
                
                while editor.find(find_text):
                    editor.textCursor().insertText(replace_text)
                
                editor.textCursor().endEditBlock()

class TextEditor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Текстовый редактор")
        self.setGeometry(100, 100, 800, 600)
        
        # Создаем вкладки
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.setCentralWidget(self.tabs)
        
        # Статус бар
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Создаем тулбар
        self.create_toolbar()
        
        # Создаем меню
        self.create_menus()
        
        # Создаем первую вкладку
        self.new_file()
    
    def create_menus(self):
        menubar = self.menuBar()
        
        # Меню Файл
        file_menu = menubar.addMenu("Файл")
        
        new_action = QAction("Создать", self)
        new_action.setShortcut("Ctrl+N")
        new_action.triggered.connect(self.new_file)
        file_menu.addAction(new_action)
        
        open_action = QAction("Открыть", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.open_file)
        file_menu.addAction(open_action)
        
        save_action = QAction("Сохранить", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_file)
        file_menu.addAction(save_action)
        
        save_as_action = QAction("Сохранить как...", self)
        save_as_action.triggered.connect(self.save_file_as)
        file_menu.addAction(save_as_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("Выход", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Меню Правка
        edit_menu = menubar.addMenu("Правка")
        
        undo_action = QAction("Отменить", self)
        undo_action.setShortcut("Ctrl+Z")
        undo_action.triggered.connect(self.undo)
        edit_menu.addAction(undo_action)
        
        redo_action = QAction("Повторить", self)
        redo_action.setShortcut("Ctrl+Y")
        redo_action.triggered.connect(self.redo)
        edit_menu.addAction(redo_action)
        
        edit_menu.addSeparator()
        
        cut_action = QAction("Вырезать", self)
        cut_action.setShortcut("Ctrl+X")
        cut_action.triggered.connect(self.cut)
        edit_menu.addAction(cut_action)
        
        copy_action = QAction("Копировать", self)
        copy_action.setShortcut("Ctrl+C")
        copy_action.triggered.connect(self.copy)
        edit_menu.addAction(copy_action)
        
        paste_action = QAction("Вставить", self)
        paste_action.setShortcut("Ctrl+V")
        paste_action.triggered.connect(self.paste)
        edit_menu.addAction(paste_action)
        
        edit_menu.addSeparator()
        
        find_action = QAction("Найти и заменить", self)
        find_action.setShortcut("Ctrl+F")
        find_action.triggered.connect(self.show_find_replace)
        edit_menu.addAction(find_action)
        
        # Меню Формат
        format_menu = menubar.addMenu("Формат")
        
        bold_action = QAction("Жирный", self)
        bold_action.setShortcut("Ctrl+B")
        bold_action.triggered.connect(self.toggle_bold)
        format_menu.addAction(bold_action)
        
        italic_action = QAction("Курсив", self)
        italic_action.setShortcut("Ctrl+I")
        italic_action.triggered.connect(self.toggle_italic)
        format_menu.addAction(italic_action)
        
        underline_action = QAction("Подчеркнутый", self)
        underline_action.setShortcut("Ctrl+U")
        underline_action.triggered.connect(self.toggle_underline)
        format_menu.addAction(underline_action)
        
        # Меню Вид
        view_menu = menubar.addMenu("Вид")
        
        self.dark_mode_action = QAction("Тёмная тема", self, checkable=True)
        self.dark_mode_action.triggered.connect(self.toggle_dark_mode)
        view_menu.addAction(self.dark_mode_action)
        
        zoom_in_action = QAction("Увеличить шрифт", self)
        zoom_in_action.setShortcut("Ctrl++")
        zoom_in_action.triggered.connect(self.zoom_in)
        view_menu.addAction(zoom_in_action)
        
        zoom_out_action = QAction("Уменьшить шрифт", self)
        zoom_out_action.setShortcut("Ctrl+-")
        zoom_out_action.triggered.connect(self.zoom_out)
        view_menu.addAction(zoom_out_action)
    
    def create_toolbar(self):
        toolbar = QToolBar("Главная панель")
        self.addToolBar(toolbar)
        
        # Кнопки файлов
        new_icon = QIcon.fromTheme("document-new")
        new_action = QAction(new_icon, "Создать", self)
        new_action.triggered.connect(self.new_file)
        toolbar.addAction(new_action)
        
        open_icon = QIcon.fromTheme("document-open")
        open_action = QAction(open_icon, "Открыть", self)
        open_action.triggered.connect(self.open_file)
        toolbar.addAction(open_action)
        
        save_icon = QIcon.fromTheme("document-save")
        save_action = QAction(save_icon, "Сохранить", self)
        save_action.triggered.connect(self.save_file)
        toolbar.addAction(save_action)
        
        toolbar.addSeparator()
        
        # Кнопки форматирования
        bold_icon = QIcon.fromTheme("format-text-bold")
        bold_action = QAction(bold_icon, "Жирный", self)
        bold_action.triggered.connect(self.toggle_bold)
        toolbar.addAction(bold_action)
        
        italic_icon = QIcon.fromTheme("format-text-italic")
        italic_action = QAction(italic_icon, "Курсив", self)
        italic_action.triggered.connect(self.toggle_italic)
        toolbar.addAction(italic_action)
        
        underline_icon = QIcon.fromTheme("format-text-underline")
        underline_action = QAction(underline_icon, "Подчеркнутый", self)
        underline_action.triggered.connect(self.toggle_underline)
        toolbar.addAction(underline_action)
        
        toolbar.addSeparator()
        
        # Кнопки поиска
        find_icon = QIcon.fromTheme("edit-find")
        find_action = QAction(find_icon, "Найти и заменить", self)
        find_action.triggered.connect(self.show_find_replace)
        toolbar.addAction(find_action)
    
    def current_editor(self):
        return self.tabs.currentWidget()
    
    def new_file(self):
        editor = QTextEdit()
        editor.setFont(QFont("Monospace", 12))
        editor.textChanged.connect(self.update_status_bar)
        
        highlighter = PythonHighlighter(editor.document())
        
        self.tabs.addTab(editor, "Новый файл")
        self.tabs.setCurrentWidget(editor)
        
        editor.setFocus()
    
    def open_file(self):
        filename, _ = QFileDialog.getOpenFileName(
            self, "Открыть файл", "", 
            "Текстовые файлы (*.txt);;Python файлы (*.py);;Все файлы (*)"
        )
        
        if filename:
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
            
            editor = QTextEdit()
            editor.setFont(QFont("Monospace", 12))
            editor.setPlainText(content)
            editor.textChanged.connect(self.update_status_bar)
            
            highlighter = PythonHighlighter(editor.document())
            
            self.tabs.addTab(editor, filename.split('/')[-1])
            self.tabs.setCurrentWidget(editor)
            
            editor.setFocus()
    
    def save_file(self):
        editor = self.current_editor()
        if not editor:
            return
        
        current_index = self.tabs.currentIndex()
        tab_text = self.tabs.tabText(current_index)
        
        if tab_text == "Новый файл":
            self.save_file_as()
        else:
            with open(tab_text, 'w', encoding='utf-8') as f:
                f.write(editor.toPlainText())
            
            self.status_bar.showMessage(f"Файл сохранён: {tab_text}", 3000)
    
    def save_file_as(self):
        editor = self.current_editor()
        if not editor:
            return
        
        filename, _ = QFileDialog.getSaveFileName(
            self, "Сохранить файл", "", 
            "Текстовые файлы (*.txt);;Python файлы (*.py);;Все файлы (*)"
        )
        
        if filename:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(editor.toPlainText())
            
            current_index = self.tabs.currentIndex()
            self.tabs.setTabText(current_index, filename.split('/')[-1])
            
            self.status_bar.showMessage(f"Файл сохранён как: {filename}", 3000)
    
    def close_tab(self, index):
        editor = self.tabs.widget(index)
        if editor:
            if editor.document().isModified():
                reply = QMessageBox.question(
                    self, "Закрыть вкладку",
                    "В файле есть несохранённые изменения. Закрыть без сохранения?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply == QMessageBox.No:
                    return
            
            editor.deleteLater()
            self.tabs.removeTab(index)
    
    def update_status_bar(self):
        editor = self.current_editor()
        if editor:
            text = editor.toPlainText()
            lines = text.count('\n') + 1
            words = len(re.findall(r'\w+', text))
            chars = len(text)
            
            self.status_bar.showMessage(f"Строк: {lines} | Слов: {words} | Символов: {chars}")
    
    def show_find_replace(self):
        if not hasattr(self, 'find_replace_dialog'):
            self.find_replace_dialog = FindReplaceDialog(self)
        self.find_replace_dialog.show()
    
    def toggle_bold(self):
        editor = self.current_editor()
        if editor:
            fmt = QTextCharFormat()
            fmt.setFontWeight(QFont.Bold if not self.is_bold() else QFont.Normal)
            
            cursor = editor.textCursor()
            cursor.mergeCharFormat(fmt)
            editor.mergeCurrentCharFormat(fmt)
    
    def toggle_italic(self):
        editor = self.current_editor()
        if editor:
            fmt = QTextCharFormat()
            fmt.setFontItalic(not self.is_italic())
            
            cursor = editor.textCursor()
            cursor.mergeCharFormat(fmt)
            editor.mergeCurrentCharFormat(fmt)
    
    def toggle_underline(self):
        editor = self.current_editor()
        if editor:
            fmt = QTextCharFormat()
            fmt.setFontUnderline(not self.is_underline())
            
            cursor = editor.textCursor()
            cursor.mergeCharFormat(fmt)
            editor.mergeCurrentCharFormat(fmt)
    
    def is_bold(self):
        editor = self.current_editor()
        if editor:
            return editor.fontWeight() == QFont.Bold
        return False
    
    def is_italic(self):
        editor = self.current_editor()
        if editor:
            return editor.fontItalic()
        return False
    
    def is_underline(self):
        editor = self.current_editor()
        if editor:
            return editor.fontUnderline()
        return False
    
    def toggle_dark_mode(self, checked):
        palette = self.palette()
        
        if checked:
            # Тёмная тема
            palette.setColor(QPalette.Window, QColor(53, 53, 53))
            palette.setColor(QPalette.WindowText, Qt.white)
            palette.setColor(QPalette.Base, QColor(25, 25, 25))
            palette.setColor(QPalette.Text, Qt.white)
            palette.setColor(QPalette.Button, QColor(53, 53, 53))
            palette.setColor(QPalette.ButtonText, Qt.white)
        else:
            # Светлая тема
            palette.setColor(QPalette.Window, QColor(240, 240, 240))
            palette.setColor(QPalette.WindowText, Qt.black)
            palette.setColor(QPalette.Base, Qt.white)
            palette.setColor(QPalette.Text, Qt.black)
            palette.setColor(QPalette.Button, QColor(240, 240, 240))
            palette.setColor(QPalette.ButtonText, Qt.black)
        
        self.setPalette(palette)
        
        # Обновляем все редакторы
        for i in range(self.tabs.count()):
            editor = self.tabs.widget(i)
            if editor:
                editor.setStyleSheet("""
                    QTextEdit {
                        background-color: %s;
                        color: %s;
                    }
                """ % (
                    palette.base().color().name(),
                    palette.text().color().name()
                ))
    
    def zoom_in(self):
        editor = self.current_editor()
        if editor:
            font = editor.font()
            font.setPointSize(font.pointSize() + 1)
            editor.setFont(font)
    
    def zoom_out(self):
        editor = self.current_editor()
        if editor:
            font = editor.font()
            if font.pointSize() > 6:
                font.setPointSize(font.pointSize() - 1)
                editor.setFont(font)
    
    def undo(self):
        editor = self.current_editor()
        if editor:
            editor.undo()
    
    def redo(self):
        editor = self.current_editor()
        if editor:
            editor.redo()
    
    def cut(self):
        editor = self.current_editor()
        if editor:
            editor.cut()
    
    def copy(self):
        editor = self.current_editor()
        if editor:
            editor.copy()
    
    def paste(self):
        editor = self.current_editor()
        if editor:
            editor.paste()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    editor = TextEditor()
    editor.show()
    sys.exit(app.exec_())