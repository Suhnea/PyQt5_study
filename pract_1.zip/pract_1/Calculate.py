from PyQt5.QtWidgets import (QApplication, QWidget, QPushButton, QLineEdit, 
                            QGridLayout, QVBoxLayout, QLabel, QComboBox)
from PyQt5.QtCore import Qt, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont, QPalette, QColor
import sys

class Calculator(QWidget):
    def __init__(self):
        super().__init__()
        self.history = []
        self.dark_mode = False
        self.initUI()
        
    def initUI(self):
        # Основные настройки окна
        self.setWindowTitle('Калькулятор')
        self.setMinimumSize(300, 400)
        
        # Главный макет
        main_layout = QVBoxLayout()
        self.setLayout(main_layout)
        
        # Выбор темы
        self.theme_combobox = QComboBox()
        self.theme_combobox.addItems(["Светлая тема", "Тёмная тема"])
        self.theme_combobox.currentIndexChanged.connect(self.change_theme)
        main_layout.addWidget(self.theme_combobox)
        
        # Поле вывода истории
        self.history_label = QLabel()
        self.history_label.setAlignment(Qt.AlignRight)
        self.history_label.setStyleSheet("color: gray;")
        self.history_label.setMaximumHeight(30)
        main_layout.addWidget(self.history_label)
        
        # Поле ввода/вывода
        self.display = QLineEdit()
        self.display.setAlignment(Qt.AlignRight)
        self.display.setReadOnly(True)
        self.display.setStyleSheet("font-size: 24px;")
        self.display.setMinimumHeight(50)
        main_layout.addWidget(self.display)
        
        # Кнопки калькулятора
        buttons_layout = QGridLayout()
        
        buttons = [
            '7', '8', '9', '/', 'C',
            '4', '5', '6', '*', '(',
            '1', '2', '3', '-', ')',
            '0', '.', '=', '+', '±',
            '⌫', 'H', ' ', ' ', ' '
        ]
        
        row, col = 0, 0
        for btn in buttons:
            button = QPushButton(btn)
            button.setMinimumSize(50, 50)
            
            # Настройка стилей для разных типов кнопок
            if btn in ['C', '⌫']:
                button.setStyleSheet("background-color: #ff6666; color: white;")
            elif btn == '=':
                button.setStyleSheet("background-color: #66cc66; color: white;")
            elif btn in ['+', '-', '*', '/', '±', '(', ')']:
                button.setStyleSheet("background-color: #66a3ff; color: white;")
            elif btn == 'H':
                button.setStyleSheet("background-color: #ffcc66; color: black;")
                button.setToolTip("Показать историю вычислений")
            
            button.clicked.connect(lambda _, ch=btn: self.handle_click(ch))
            
            # Назначение горячих клавиш
            if btn == '=':
                button.setShortcut('Enter')
            elif btn == 'C':
                button.setShortcut('Esc')
            elif btn == '⌫':
                button.setShortcut('Backspace')
            
            buttons_layout.addWidget(button, row, col)
            col += 1
            if col > 4:
                col = 0
                row += 1
        
        main_layout.addLayout(buttons_layout)
        
        # Применяем светлую тему по умолчанию
        self.apply_theme(False)
        
    def handle_click(self, char):
        current_text = self.display.text()
        
        if char == '=':
            try:
                expression = current_text
                result = str(eval(expression))
                self.history.append(f"{expression} = {result}")
                if len(self.history) > 5:
                    self.history.pop(0)
                self.display.setText(result)
                self.update_history_label()
            except ZeroDivisionError:
                self.display.setText("Ошибка: деление на ноль")
            except:
                self.display.setText("Ошибка")
                
        elif char == 'C':
            self.display.clear()
            
        elif char == '±':
            if current_text and current_text[0] == '-':
                self.display.setText(current_text[1:])
            elif current_text:
                self.display.setText('-' + current_text)
                
        elif char == '⌫':
            self.display.setText(current_text[:-1])
            
        elif char == 'H':
            self.show_history()
            
        elif char == ' ':
            pass  # Пустая кнопка для выравнивания
            
        else:
            self.display.setText(current_text + char)
    
    def update_history_label(self):
        if self.history:
            self.history_label.setText(self.history[-1])
        else:
            self.history_label.clear()
    
    def show_history(self):
        if self.history:
            history_text = "\n".join(self.history)
            self.history_label.setText(history_text)
            # Анимация появления полной истории
            anim = QPropertyAnimation(self.history_label, b"maximumHeight")
            anim.setDuration(500)
            anim.setStartValue(30)
            anim.setEndValue(150)
            anim.setEasingCurve(QEasingCurve.InOutQuad)
            anim.start()
        else:
            self.history_label.setText("История пуста")
    
    def change_theme(self):
        self.dark_mode = self.theme_combobox.currentIndex() == 1
        self.apply_theme(self.dark_mode)
    
    def apply_theme(self, dark):
        palette = self.palette()
        
        if dark:
            # Тёмная тема
            palette.setColor(QPalette.Window, QColor(53, 53, 53))
            palette.setColor(QPalette.WindowText, Qt.white)
            palette.setColor(QPalette.Base, QColor(25, 25, 25))
            palette.setColor(QPalette.Text, Qt.white)
            palette.setColor(QPalette.Button, QColor(53, 53, 53))
            palette.setColor(QPalette.ButtonText, Qt.white)
            self.setStyleSheet("""
                QLineEdit, QLabel, QComboBox {
                    background-color: #191919;
                    color: white;
                    border: 1px solid #444;
                }
                QComboBox QAbstractItemView {
                    background-color: #353535;
                    color: white;
                }
            """)
        else:
            # Светлая тема
            palette.setColor(QPalette.Window, QColor(240, 240, 240))
            palette.setColor(QPalette.WindowText, Qt.black)
            palette.setColor(QPalette.Base, Qt.white)
            palette.setColor(QPalette.Text, Qt.black)
            palette.setColor(QPalette.Button, QColor(240, 240, 240))
            palette.setColor(QPalette.ButtonText, Qt.black)
            self.setStyleSheet("""
                QLineEdit, QLabel, QComboBox {
                    background-color: white;
                    color: black;
                    border: 1px solid #ccc;
                }
            """)
        
        self.setPalette(palette)
    
    def keyPressEvent(self, event):
        # Обработка дополнительных горячих клавиш
        if event.key() == Qt.Key_H:
            self.show_history()
        elif event.key() == Qt.Key_Escape:
            self.display.clear()
        else:
            super().keyPressEvent(event)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')  # Современный стиль виджетов
    
    # Установка шрифта
    font = QFont()
    font.setPointSize(10)
    app.setFont(font)
    
    calc = Calculator()
    calc.show()
    sys.exit(app.exec_())