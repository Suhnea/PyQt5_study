import sqlite3

def create_tables():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    # Создаем таблицу продуктов
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL
    )
    ''')
    
    conn.commit()
    conn.close()

def add_sample_data():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    # Проверяем, есть ли уже данные в таблице
    cursor.execute("SELECT COUNT(*) FROM products")
    count = cursor.fetchone()[0]
    
    if count == 0:
        # Добавляем тестовые данные
        sample_data = [
            ("Борщ", 250),
            ("Стейк", 500),
            ("Салат", 180),
            ("Кофе", 120),
            ("Десерт", 200),
            ("Суп", 150),
            ("Рыба", 350),
            ("Пицца", 400)
        ]
        
        cursor.executemany("INSERT INTO products (name, price) VALUES (?, ?)", sample_data)
        conn.commit()
    
    conn.close()

def get_all_products():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products")
    data = cursor.fetchall()
    conn.close()
    return data

def add_product(name, price):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO products (name, price) VALUES (?, ?)", (name, price))
    conn.commit()
    conn.close()