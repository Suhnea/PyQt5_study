from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QListWidget, QTableWidget, QTableWidgetItem,
    QLabel, QPushButton, QFrame, QCheckBox, 
    QLineEdit, QComboBox, QStyleFactory, QMessageBox, QApplication
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPalette, QColor
import sqlite3

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Главное окно")
        self.setGeometry(100, 100, 800, 600)
        
        # Основной контейнер
        main_widget = QWidget()
        main_layout = QHBoxLayout()
        
        # Боковое меню
        self.menu = QListWidget()
        self.menu.addItems(["Таблица данных", "Композиция виджетов", "Резервная страница"])
        self.menu.currentRowChanged.connect(self.switch_view)
        
        # Область контента
        self.content_area = QWidget()
        self.content_layout = QVBoxLayout()
        self.content_area.setLayout(self.content_layout)
        
        # Панель управления темой
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(QStyleFactory.keys())
        self.theme_combo.currentTextChanged.connect(self.change_theme)
        
        main_layout.addWidget(self.menu, stretch=1)
        main_layout.addWidget(self.content_area, stretch=4)
        
        # Добавляем панель управления темой в основной layout
        control_layout = QVBoxLayout()
        control_layout.addLayout(main_layout)
        control_layout.addWidget(QLabel("Выберите тему:"))
        control_layout.addWidget(self.theme_combo)
        
        main_widget.setLayout(control_layout)
        self.setCentralWidget(main_widget)
        
        # Инициализация стартового вида
        self.show_table_view()
    
    def switch_view(self, index):
        self.clear_content()
        if index == 0:
            self.show_table_view()
        elif index == 1:
            self.show_widgets_composition()
        else:
            self.show_reserve_page()
    
    def clear_content(self):
        for i in reversed(range(self.content_layout.count())):
            widget = self.content_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)
    
    def show_table_view(self):
        try:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM products")
            data = cursor.fetchall()
            conn.close()
            
            table = QTableWidget()
            table.setColumnCount(3)
            table.setRowCount(len(data))
            table.setHorizontalHeaderLabels(["ID", "Название", "Цена"])
            
            for row, item in enumerate(data):
                for col, value in enumerate(item):
                    table.setItem(row, col, QTableWidgetItem(str(value)))
            
            self.content_layout.addWidget(table)
            
            # Кнопка для обновления данных
            refresh_btn = QPushButton("Обновить данные")
            refresh_btn.clicked.connect(self.show_table_view)
            self.content_layout.addWidget(refresh_btn)
            
        except sqlite3.Error as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить данные: {str(e)}")
    
    def show_widgets_composition(self):
        frame = QFrame()
        frame.setFrameShape(QFrame.StyledPanel)
        
        grid = QVBoxLayout()
        grid.setSpacing(20)
        
        # Верхний ряд
        top_layout = QHBoxLayout()
        label = QLabel("Текст (Сверху слева)")
        label.setAlignment(Qt.AlignCenter)
        top_layout.addWidget(label)
        
        btn = QPushButton("Кнопка (Сверху справа)")
        btn.clicked.connect(lambda: QMessageBox.information(self, "Инфо", "Кнопка нажата!"))
        top_layout.addWidget(btn)
        
        # Нижний ряд
        bottom_layout = QHBoxLayout()
        line_edit = QLineEdit()
        line_edit.setPlaceholderText("Поле ввода (Снизу слева)")
        bottom_layout.addWidget(line_edit)
        
        checkbox = QCheckBox("Чекбокс (Снизу справа)")
        bottom_layout.addWidget(checkbox)
        
        grid.addLayout(top_layout)
        grid.addLayout(bottom_layout)
        
        frame.setLayout(grid)
        self.content_layout.addWidget(frame)
    
    def show_reserve_page(self):
        label = QLabel("Резервная страница\n\nЗдесь может быть ваш контент")
        label.setAlignment(Qt.AlignCenter)
        self.content_layout.addWidget(label)
    
    def change_theme(self, theme_name):
        try:
            # Устанавливаем стиль
            QApplication.setStyle(QStyleFactory.create(theme_name))
            
            # Дополнительные настройки для темной темы
            if "dark" in theme_name.lower():
                dark_palette = QPalette()
                dark_palette.setColor(QPalette.Window, QColor(53, 53, 53))
                dark_palette.setColor(QPalette.WindowText, Qt.white)
                dark_palette.setColor(QPalette.Base, QColor(25, 25, 25))
                dark_palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
                dark_palette.setColor(QPalette.ToolTipBase, Qt.white)
                dark_palette.setColor(QPalette.ToolTipText, Qt.white)
                dark_palette.setColor(QPalette.Text, Qt.white)
                dark_palette.setColor(QPalette.Button, QColor(53, 53, 53))
                dark_palette.setColor(QPalette.ButtonText, Qt.white)
                dark_palette.setColor(QPalette.BrightText, Qt.red)
                dark_palette.setColor(QPalette.Link, QColor(42, 130, 218))
                dark_palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
                dark_palette.setColor(QPalette.HighlightedText, Qt.black)
                QApplication.setPalette(dark_palette)
            else:
                QApplication.setPalette(QApplication.style().standardPalette())
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось применить тему: {str(e)}")