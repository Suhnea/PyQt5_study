from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout,
    QLabel, QLineEdit, QPushButton, QMessageBox
)
from PyQt5.QtCore import Qt
from main_window import MainWindow
from database import create_tables, add_sample_data

class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Авторизация")
        self.setFixedSize(300, 200)
        
        # Инициализация базы данных
        create_tables()
        add_sample_data()
        
        central_widget = QWidget()
        layout = QVBoxLayout()
        
        self.login_input = QLineEdit()
        self.login_input.setPlaceholderText("Логин")
        
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Пароль")
        self.password_input.setEchoMode(QLineEdit.Password)
        
        login_btn = QPushButton("Войти")
        login_btn.clicked.connect(self.check_credentials)
        
        # Горячая клавиша Enter для входа
        login_btn.setShortcut(Qt.Key_Return)
        
        layout.addWidget(QLabel("Введите данные:"))
        layout.addWidget(self.login_input)
        layout.addWidget(self.password_input)
        layout.addWidget(login_btn)
        
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)
    
    def check_credentials(self):
        if self.login_input.text() == "admin" and self.password_input.text() == "123":
            self.close()
            self.main_window = MainWindow()
            self.main_window.show()
        else:
            QMessageBox.warning(self, "Ошибка", "Неверный логин или пароль!")