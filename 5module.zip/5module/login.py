from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel, 
                             QComboBox, QLineEdit, QPushButton, QMessageBox)
from PyQt5.QtCore import Qt
import hashlib
import json
import os

class LoginWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Стражник – Вход")
        self.setFixedSize(400, 350)
        
        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Основной layout
        layout = QVBoxLayout()
        central_widget.setLayout(layout)
        
        # Заголовок
        title_label = QLabel("Вход в систему")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; margin-bottom: 20px;")
        layout.addWidget(title_label)
        
        # Тип пользователя
        self.user_type_label = QLabel("Тип пользователя")
        self.user_type_combo = QComboBox()
        self.user_type_combo.addItems(["Администратор доступа", "Сотрудник службы безопасности"])
        layout.addWidget(self.user_type_label)
        layout.addWidget(self.user_type_combo)
        
        # Логин
        self.login_label = QLabel("Логин")
        self.login_input = QLineEdit()
        self.login_input.setPlaceholderText("Введите логин")
        layout.addWidget(self.login_label)
        layout.addWidget(self.login_input)
        
        # Пароль
        self.password_label = QLabel("Пароль")
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Введите пароль")
        self.password_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)
        
        # Секретное слово
        self.secret_label = QLabel("Секретное слово")
        self.secret_input = QLineEdit()
        self.secret_input.setPlaceholderText("Введите секретное слово")
        self.secret_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.secret_label)
        layout.addWidget(self.secret_input)
        
        # Кнопка входа
        self.login_button = QPushButton("Войти в систему")
        self.login_button.clicked.connect(self.authenticate)
        layout.addWidget(self.login_button)
        
        # Кнопка "Забыли данные"
        self.forgot_button = QPushButton("Забыли данные для входа")
        self.forgot_button.setStyleSheet("background: none; border: none; color: blue; text-decoration: underline;")
        self.forgot_button.clicked.connect(self.show_forgot_info)
        layout.addWidget(self.forgot_button)
        
        # Загрузка пользователей
        self.users = self.load_users()
        self.login_success = None
        
    def load_users(self):
        """Загружает пользователей из файла или создает стандартных пользователей"""
        if not os.path.exists('users.json'):
            # Создаем стандартных пользователей, если файла нет
            default_users = {
                "Администратор доступа": {
                    "guardianskk": {
                        "password": self.hash_password("AdminPass123!"),
                        "secret": self.hash_password("admin_secret"),
                        "full_name": "Иванов И.И."
                    }
                },
                "Сотрудник службы безопасности": {
                    "defendservice": {
                        "password": self.hash_password("SecurityPass123!"),
                        "secret": self.hash_password("security_secret"),
                        "full_name": "Петров П.П."
                    }
                }
            }
            with open('users.json', 'w') as f:
                json.dump(default_users, f, indent=4)
            return default_users
        
        with open('users.json', 'r') as f:
            return json.load(f)
    
    def hash_password(self, password):
        """Хеширует пароль с использованием SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def validate_password(self, password):
        """Проверяет сложность пароля"""
        if len(password) < 8:
            return False
        if not any(c.isupper() for c in password):
            return False
        if not any(c.islower() for c in password):
            return False
        if not any(c.isdigit() for c in password):
            return False
        if not any(not c.isalnum() for c in password):
            return False
        return True
    
    def authenticate(self):
        """Проверяет введенные данные пользователя"""
        user_type = self.user_type_combo.currentText()
        login = self.login_input.text().strip()
        password = self.password_input.text()
        secret = self.secret_input.text()
        
        # Проверка на пустые поля
        if not all([login, password, secret]):
            QMessageBox.warning(self, "Ошибка", "Все поля должны быть заполнены!")
            return
        
        # Проверка сложности пароля
        if not self.validate_password(password):
            QMessageBox.warning(self, "Ошибка", 
                "Пароль должен содержать:\n- минимум 8 символов\n- заглавные и строчные буквы\n- цифры\n- специальные символы")
            return
        
        # Проверка существования пользователя
        if user_type not in self.users or login not in self.users[user_type]:
            QMessageBox.warning(self, "Ошибка", "Неверный логин или тип пользователя!")
            return
        
        user_data = self.users[user_type][login]
        
        # Проверка пароля и секретного слова
        if (self.hash_password(password) != user_data["password"] or 
            self.hash_password(secret) != user_data["secret"]):
            QMessageBox.warning(self, "Ошибка", "Неверный пароль или секретное слово!")
            return
        
        # Успешная авторизация
        QMessageBox.information(self, "Успех", f"Добро пожаловать, {user_data['full_name']}!")
        self.close()
        if self.login_success:
            self.login_success(user_data['full_name'], user_type)
    
    def show_forgot_info(self):
        """Показывает информацию о восстановлении доступа"""
        QMessageBox.information(self, "Восстановление доступа", 
            "Для восстановления доступа обратитесь к системному администратору.")