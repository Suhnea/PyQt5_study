import sys
from PyQt5.QtWidgets import QApplication
from login import LoginWindow
from admin_window import AdminWindow
from pass_request import PassRequestWindow
from traffic_emulator import TrafficEmulator

class Controller:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.app.setStyle("Fusion")
        
        self.login_window = None
        self.admin_window = None
        self.security_windows = []  # Для хранения окон сотрудника безопасности
    
    def show_login(self):
        self.login_window = LoginWindow()
        self.login_window.login_success = self.show_main_window
        self.login_window.show()
        sys.exit(self.app.exec_())
    
    def show_main_window(self, user_fullname, user_type):
        self.login_window.close()
        
        if user_type == "Администратор доступа":
            self.admin_window = AdminWindow(user_fullname)
            self.admin_window.show()
        elif user_type == "Сотрудник службы безопасности":
            self.show_security_interface(user_fullname)
    
    def show_security_interface(self, user_fullname):
        # Окно оформления пропусков
        pass_request = PassRequestWindow(user_fullname)
        pass_request.show()
        
        # Окно мониторинга
        monitor = TrafficEmulator()
        monitor.show()
        
        # Сохраняем ссылки на окна
        self.security_windows.extend([pass_request, monitor])
        
        # Связываем закрытие окон
        pass_request.destroyed.connect(lambda: self.on_security_window_close(monitor))
        monitor.destroyed.connect(lambda: self.on_security_window_close(pass_request))
    
    def on_security_window_close(self, window_to_close):
        if window_to_close in self.security_windows:
            window_to_close.close()
        self.security_windows = [w for w in self.security_windows if w.isVisible()]

if __name__ == "__main__":
    controller = Controller()
    controller.show_login()