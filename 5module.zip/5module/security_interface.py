from PyQt5.QtWidgets import (QMainWindow, QTabWidget, QWidget, QVBoxLayout, 
                            QHBoxLayout, QLabel, QTextEdit, QListWidget, 
                            QListWidgetItem)
from PyQt5.QtCore import Qt, QTimer, QDateTime
from PyQt5.QtGui import QFont, QColor, QTextCursor
import random
import json

class SecurityInterface(QMainWindow):
    def __init__(self, user_fullname):
        super().__init__()
        self.user_fullname = user_fullname
        self.setWindowTitle(f"Страхник - Служба безопасности ({user_fullname})")
        self.setGeometry(100, 100, 1200, 700)
        
        # Основной виджет с вкладками
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        
        # Вкладка мониторинга
        self.create_monitor_tab()
        
        # Вкладка оформления пропусков
        self.create_pass_request_tab()
        
        # Загрузка данных
        self.load_data()
        
        # Таймер обновления
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_monitor)
        self.timer.start(3000)
        
        # Статистика
        self.visitors_today = 0
        self.employees_today = 0
        self.unknown_today = 0
        
        self.log_event("Система инициализирована", QColor(0, 100, 0))
    
    def load_data(self):
        """Загрузка тестовых данных"""
        try:
            with open('employees.json', 'r') as f:
                self.employees = json.load(f)
        except:
            self.employees = [
                {"fio": "Иванов И.И.", "position": "Отдел кадров"},
                {"fio": "Петрова А.С.", "position": "Бухгалтерия"}
            ]
        
        try:
            with open('pass_requests.json', 'r') as f:
                self.visitors = json.load(f)
        except:
            self.visitors = []
    
    def create_monitor_tab(self):
        """Создает вкладку мониторинга"""
        tab = QWidget()
        layout = QHBoxLayout(tab)
        
        # Лог событий
        self.event_log = QTextEdit()
        self.event_log.setReadOnly(True)
        self.event_log.setFont(QFont("Courier New", 10))
        
        # Правая панель
        right_panel = QVBoxLayout()
        
        # Статистика
        self.stats_label = QLabel("Статистика:")
        self.stats_label.setFont(QFont("Arial", 12, QFont.Bold))
        
        self.stats_text = QLabel()
        self.stats_text.setFont(QFont("Arial", 10))
        
        # Текущие посетители
        self.current_visitors_label = QLabel("Сейчас в здании:")
        self.current_visitors_label.setFont(QFont("Arial", 12, QFont.Bold))
        
        self.current_visitors_list = QListWidget()
        
        right_panel.addWidget(self.stats_label)
        right_panel.addWidget(self.stats_text)
        right_panel.addWidget(self.current_visitors_label)
        right_panel.addWidget(self.current_visitors_list)
        right_panel.addStretch()
        
        layout.addWidget(self.event_log, 70)
        layout.addLayout(right_panel, 30)
        
        self.tabs.addTab(tab, "Мониторинг")
    
    def create_pass_request_tab(self):
        """Создает вкладку оформления пропусков"""
        from pass_request import PassRequestForm  # Локальный импорт
        
        tab = QWidget()
        layout = QVBoxLayout(tab)
        
        self.pass_request_form = PassRequestForm()
        layout.addWidget(self.pass_request_form)
        
        self.tabs.addTab(tab, "Оформление пропусков")
    
    def update_monitor(self):
        """Обновление данных мониторинга"""
        event_type = random.choice(["employee_in", "visitor_in", "unknown"])
        
        if event_type == "employee_in" and self.employees:
            emp = random.choice(self.employees)
            self.log_event(f"Вход сотрудника: {emp['fio']}", QColor(0, 100, 0))
            self.add_current_visitor(emp['fio'], "employee")
            self.employees_today += 1
        
        elif event_type == "visitor_in" and self.visitors:
            visitor = random.choice(self.visitors)
            name = f"{visitor['visitor']['last_name']} {visitor['visitor']['first_name']}"
            self.log_event(f"Вход посетителя: {name}", QColor(0, 0, 139))
            self.add_current_visitor(name, "visitor")
            self.visitors_today += 1
        
        elif event_type == "unknown":
            self.log_event("Попытка входа неизвестного", QColor(255, 0, 0))
            self.unknown_today += 1
        
        self.update_stats()
    
    def add_current_visitor(self, name, vtype):
        """Добавляет посетителя в список"""
        item = QListWidgetItem(name)
        color = QColor(200, 255, 200) if vtype == "employee" else QColor(200, 200, 255)
        item.setBackground(color)
        self.current_visitors_list.addItem(item)
    
    def update_stats(self):
        """Обновляет статистику"""
        stats = (f"Посетители: {self.visitors_today}\n"
                f"Сотрудники: {self.employees_today}\n"
                f"Отказы: {self.unknown_today}")
        self.stats_text.setText(stats)
    
    def log_event(self, message, color):
        """Логирование событий"""
        cursor = self.event_log.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.event_log.setTextCursor(cursor)
        self.event_log.setTextColor(color)
        self.event_log.insertPlainText(f"{QDateTime.currentDateTime().toString('hh:mm:ss')} - {message}\n")

    def closeEvent(self, event):
        """При закрытии окна"""
        self.timer.stop()
        event.accept()