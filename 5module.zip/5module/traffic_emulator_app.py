from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                            QLabel, QTextEdit, QListWidget, QListWidgetItem,
                            QApplication)
from PyQt5.QtCore import Qt, QTimer, QDateTime
from PyQt5.QtGui import QFont, QColor, QTextCursor
import json
import random

class TrafficEmulator(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Стражник - Мониторинг трафика")
        self.setGeometry(200, 200, 900, 600)
        
        # Инициализация данных
        self.employees = []
        self.visitors = []
        self.current_visitors = []
        self.visitors_today = 0
        self.employees_today = 0
        self.unknown_today = 0
        
        # Создаем UI
        self.init_ui()
        
        # Загружаем тестовые данные
        self.load_test_data()
        
        # Запускаем таймер
        self.timer = QTimer()
        self.timer.timeout.connect(self.generate_event)
        self.timer.start(2000)  # Обновление каждые 2 секунды
        
        # Первое сообщение
        self.log_event("Система мониторинга запущена", QColor(0, 100, 0))
    
    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)
        
        # Лог событий (левая часть)
        self.event_log = QTextEdit()
        self.event_log.setReadOnly(True)
        self.event_log.setFont(QFont("Courier New", 10))
        
        # Правая панель
        right_panel = QVBoxLayout()
        
        # Статистика
        stats_label = QLabel("Статистика:")
        stats_label.setFont(QFont("Arial", 12, QFont.Bold))
        
        self.stats_text = QLabel("0 посетителей\n0 сотрудников\n0 отказов")
        self.stats_text.setFont(QFont("Arial", 10))
        
        # Список посетителей
        visitors_label = QLabel("Сейчас в здании:")
        visitors_label.setFont(QFont("Arial", 12, QFont.Bold))
        
        self.visitors_list = QListWidget()
        
        right_panel.addWidget(stats_label)
        right_panel.addWidget(self.stats_text)
        right_panel.addWidget(visitors_label)
        right_panel.addWidget(self.visitors_list)
        right_panel.addStretch()
        
        main_layout.addWidget(self.event_log, 70)
        main_layout.addLayout(right_panel, 30)
    
    def load_test_data(self):
        """Загрузка тестовых данных"""
        self.employees = [
            {"fio": "Иванов И.И.", "position": "Отдел кадров"},
            {"fio": "Петрова А.С.", "position": "Бухгалтерия"}
        ]
        
        self.visitors = [
            {"visitor": {"last_name": "Сидоров", "first_name": "Алексей"}, "purpose": "Встреча"},
            {"visitor": {"last_name": "Кузнецова", "first_name": "Мария"}, "purpose": "Доставка"}
        ]
    
    def generate_event(self):
        """Генерация тестовых событий"""
        event_type = random.choice(["employee_in", "visitor_in", "unknown"])
        
        if event_type == "employee_in":
            emp = random.choice(self.employees)
            name = emp["fio"]
            self.log_event(f"Вход сотрудника: {name}", QColor(0, 100, 0))
            self.add_visitor(name, "employee")
            self.employees_today += 1
        
        elif event_type == "visitor_in":
            visitor = random.choice(self.visitors)
            name = f"{visitor['visitor']['last_name']} {visitor['visitor']['first_name']}"
            purpose = visitor.get('purpose', 'не указана')
            self.log_event(f"Вход посетителя: {name} ({purpose})", QColor(0, 0, 139))
            self.add_visitor(name, "visitor")
            self.visitors_today += 1
        
        elif event_type == "unknown":
            self.log_event("Попытка входа неизвестного лица", QColor(139, 0, 0))
            self.unknown_today += 1
        
        self.update_stats()
    
    def add_visitor(self, name, vtype):
        """Добавление посетителя в список"""
        item = QListWidgetItem(name)
        item.setData(Qt.UserRole, vtype)
        color = QColor(200, 255, 200) if vtype == "employee" else QColor(200, 200, 255)
        item.setBackground(color)
        self.visitors_list.addItem(item)
    
    def log_event(self, message, color=None):
        """Логирование события"""
        timestamp = QDateTime.currentDateTime().toString("hh:mm:ss")
        self.event_log.moveCursor(QTextCursor.End)
        if color:
            self.event_log.setTextColor(color)
        self.event_log.insertPlainText(f"{timestamp} - {message}\n")
        self.event_log.ensureCursorVisible()
    
    def update_stats(self):
        """Обновление статистики"""
        stats = (f"Посетителей: {self.visitors_today}\n"
                f"Сотрудников: {self.employees_today}\n"
                f"Отказов: {self.unknown_today}")
        self.stats_text.setText(stats)

if __name__ == "__main__":
    app = QApplication([])
    window = TrafficEmulator()
    window.show()
    app.exec_()