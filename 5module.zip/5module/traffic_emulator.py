from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                            QLabel, QTextEdit, QListWidget, QListWidgetItem)
from PyQt5.QtCore import Qt, QTimer, QDateTime
from PyQt5.QtGui import QFont, QColor, QTextCursor
import random

class TrafficEmulator(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Страхник - Мониторинг трафика")
        self.setGeometry(200, 200, 900, 600)
        
        # Данные
        self.employees = [
            {"fio": "Иванов И.И.", "position": "Отдел кадров"},
            {"fio": "Петрова А.С.", "position": "Бухгалтерия"}
        ]
        self.visitors = [
            {"visitor": {"last_name": "Сидоров", "first_name": "Алексей"}, "purpose": "Встреча"},
            {"visitor": {"last_name": "Кузнецова", "first_name": "Мария"}, "purpose": "Доставка"}
        ]
        self.current_visitors = []
        
        # Инициализация UI
        self.init_ui()
        
        # Таймер
        self.timer = QTimer(self)  # Важно: parent=self
        self.timer.timeout.connect(self.generate_event)
        self.timer.start(2000)
        
        self.log_event("Система мониторинга запущена", QColor(0, 100, 0))
    
    def init_ui(self):
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        
        layout = QHBoxLayout(central_widget)
        
        # Лог событий
        self.event_log = QTextEdit()
        self.event_log.setReadOnly(True)
        
        # Правая панель
        right_panel = QVBoxLayout()
        
        # Статистика
        self.stats_label = QLabel("Статистика:")
        self.stats_text = QLabel("0 посетителей\n0 сотрудников")
        
        # Список посетителей
        self.visitors_label = QLabel("Сейчас в здании:")
        self.visitors_list = QListWidget()
        
        right_panel.addWidget(self.stats_label)
        right_panel.addWidget(self.stats_text)
        right_panel.addWidget(self.visitors_label)
        right_panel.addWidget(self.visitors_list)
        
        layout.addWidget(self.event_log, 70)
        layout.addLayout(right_panel, 30)
    
    def generate_event(self):
        event_type = random.choice(["employee_in", "visitor_in", "unknown"])
        
        if event_type == "employee_in":
            emp = random.choice(self.employees)
            self.log_event(f"Вход сотрудника: {emp['fio']}", QColor(0, 100, 0))
            self.add_visitor(emp['fio'], "employee")
        
        elif event_type == "visitor_in":
            visitor = random.choice(self.visitors)
            name = f"{visitor['visitor']['last_name']} {visitor['visitor']['first_name']}"
            self.log_event(f"Вход посетителя: {name}", QColor(0, 0, 139))
            self.add_visitor(name, "visitor")
        
        elif event_type == "unknown":
            self.log_event("Попытка входа неизвестного", QColor(139, 0, 0))
    
    def add_visitor(self, name, vtype):
        item = QListWidgetItem(name)
        item.setBackground(QColor(200, 255, 200) if vtype == "employee" else QColor(200, 200, 255))
        self.visitors_list.addItem(item)
    
    def log_event(self, message, color):
        cursor = self.event_log.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.event_log.setTextCursor(cursor)
        
        self.event_log.setTextColor(color)
        self.event_log.insertPlainText(f"{QDateTime.currentDateTime().toString('hh:mm:ss')} - {message}\n")

    def closeEvent(self, event):
        self.timer.stop()
        event.accept()