import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QLabel, QLineEdit, QComboBox, QPushButton, QFileDialog, 
                             QMessageBox, QDateEdit, QGroupBox, QRadioButton, 
                             QStackedWidget, QFormLayout)
from PyQt5.QtCore import Qt, QDate
from PyQt5.QtGui import QPixmap
import json
import os
from datetime import datetime
import re

class PassRequestWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Форма
        form = QFormLayout()
        
        # Поля формы
        self.last_name_input = QLineEdit()
        self.first_name_input = QLineEdit()
        self.purpose_input = QLineEdit()
        self.date_input = QDateEdit()
        self.date_input.setDate(QDate.currentDate())
        
        # Добавление полей
        form.addRow("Фамилия:", self.last_name_input)
        form.addRow("Имя:", self.first_name_input)
        form.addRow("Цель визита:", self.purpose_input)
        form.addRow("Дата:", self.date_input)
        
        # Кнопка
        self.submit_btn = QPushButton("Создать пропуск")
        self.submit_btn.clicked.connect(self.create_pass)
        
        layout.addLayout(form)
        layout.addWidget(self.submit_btn)
    
    def create_pass(self):
        """Создание пропуска"""
        last_name = self.last_name_input.text()
        first_name = self.first_name_input.text()
        purpose = self.purpose_input.text()
        date = self.date_input.date().toString("dd.MM.yyyy")
        
        print(f"Создан пропуск: {last_name} {first_name}, {purpose}, {date}")
        

    def load_employees(self):
        """Загружает список сотрудников из файла"""
        if not os.path.exists('employees.json'):
            test_employees = [
                {"fio": "Иванов Иван Иванович", "position": "Отдел кадров - Менеджер"},
                {"fio": "Петрова Анна Сергеевна", "position": "Бухгалтерия - Главный бухгалтер"}
            ]
            with open('employees.json', 'w', encoding='utf-8') as f:
                json.dump(test_employees, f, ensure_ascii=False, indent=4)
            return test_employees
        
        with open('employees.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def get_departments(self):
        """Возвращает список уникальных подразделений"""
        departments = set()
        for employee in self.employees:
            if "position" in employee:
                dept = employee["position"].split('-')[0].strip()
                departments.add(dept)
        return sorted(departments)
        
    def create_individual_form(self):
        """Создает форму для индивидуальной заявки"""
        form = QWidget()
        layout = QVBoxLayout()
        form.setLayout(layout)
        
        # Информация для пропуска
        pass_group = QGroupBox("Информация для пропуска")
        pass_layout = QFormLayout()
        
        self.start_date_edit = QDateEdit()
        self.start_date_edit.setDate(QDate.currentDate().addDays(1))
        self.start_date_edit.setCalendarPopup(True)
        self.start_date_edit.setMinimumDate(QDate.currentDate().addDays(1))
        self.start_date_edit.setMaximumDate(QDate.currentDate().addDays(15))
        
        self.end_date_edit = QDateEdit()
        self.end_date_edit.setDate(QDate.currentDate().addDays(1))
        self.end_date_edit.setCalendarPopup(True)
        self.end_date_edit.setMinimumDate(QDate.currentDate().addDays(1))
        self.end_date_edit.setMaximumDate(QDate.currentDate().addDays(15))
        
        self.purpose_input = QLineEdit()
        
        pass_layout.addRow("Дата начала действия*:", self.start_date_edit)
        pass_layout.addRow("Дата окончания действия:", self.end_date_edit)
        pass_layout.addRow("Цель посещения*:", self.purpose_input)
        pass_group.setLayout(pass_layout)
        layout.addWidget(pass_group)
        
        # Принимающая сторона
        host_group = QGroupBox("Принимающая сторона")
        host_layout = QFormLayout()
        
        self.department_combo = QComboBox()
        self.department_combo.addItems(self.departments)
        self.department_combo.currentIndexChanged.connect(self.update_employees_combo)
        
        self.employee_combo = QComboBox()
        self.update_employees_combo()
        
        host_layout.addRow("Подразделение*:", self.department_combo)
        host_layout.addRow("ФИО сотрудника*:", self.employee_combo)
        host_group.setLayout(host_layout)
        layout.addWidget(host_group)
        
        # Информация о посетителе
        visitor_group = QGroupBox("Информация о посетителе")
        visitor_layout = QFormLayout()
        
        self.last_name_input = QLineEdit()
        self.first_name_input = QLineEdit()
        self.middle_name_input = QLineEdit()
        self.phone_input = QLineEdit()
        self.phone_input.setInputMask("+7 (999) 999-99-99;_")
        self.email_input = QLineEdit()
        self.organization_input = QLineEdit()
        self.birth_date_edit = QDateEdit()
        self.birth_date_edit.setMaximumDate(QDate.currentDate().addYears(-14))
        self.birth_date_edit.setCalendarPopup(True)
        self.passport_series_input = QLineEdit()
        self.passport_series_input.setMaxLength(4)
        self.passport_number_input = QLineEdit()
        self.passport_number_input.setMaxLength(6)
        
        visitor_layout.addRow("Фамилия*:", self.last_name_input)
        visitor_layout.addRow("Имя*:", self.first_name_input)
        visitor_layout.addRow("Отчество:", self.middle_name_input)
        visitor_layout.addRow("Телефон:", self.phone_input)
        visitor_layout.addRow("Email*:", self.email_input)
        visitor_layout.addRow("Организация:", self.organization_input)
        visitor_layout.addRow("Дата рождения*:", self.birth_date_edit)
        visitor_layout.addRow("Серия паспорта*:", self.passport_series_input)
        visitor_layout.addRow("Номер паспорта*:", self.passport_number_input)
        visitor_group.setLayout(visitor_layout)
        layout.addWidget(visitor_group)
        
        # Документы
        docs_group = QGroupBox("Прикрепляемые документы")
        docs_layout = QVBoxLayout()
        
        self.photo_button = QPushButton("Фотография посетителя")
        self.photo_button.clicked.connect(lambda: self.select_file("photo"))
        self.photo_path = ""
        
        self.passport_scan_button = QPushButton("Скан паспорта*")
        self.passport_scan_button.clicked.connect(lambda: self.select_file("passport"))
        self.passport_scan_path = ""
        
        docs_layout.addWidget(self.photo_button)
        docs_layout.addWidget(self.passport_scan_button)
        docs_group.setLayout(docs_layout)
        layout.addWidget(docs_group)
        
        return form
    
    def create_group_form(self):
        """Создает форму для групповой заявки"""
        form = QWidget()
        layout = QVBoxLayout()
        form.setLayout(layout)
        
        # Информация для пропуска
        pass_group = QGroupBox("Информация для пропуска")
        pass_layout = QFormLayout()
        
        self.group_start_date_edit = QDateEdit()
        self.group_start_date_edit.setDate(QDate.currentDate().addDays(1))
        self.group_start_date_edit.setCalendarPopup(True)
        self.group_start_date_edit.setMinimumDate(QDate.currentDate().addDays(1))
        self.group_start_date_edit.setMaximumDate(QDate.currentDate().addDays(15))
        
        self.group_end_date_edit = QDateEdit()
        self.group_end_date_edit.setDate(QDate.currentDate().addDays(1))
        self.group_end_date_edit.setCalendarPopup(True)
        self.group_end_date_edit.setMinimumDate(QDate.currentDate().addDays(1))
        self.group_end_date_edit.setMaximumDate(QDate.currentDate().addDays(15))
        
        self.group_purpose_input = QLineEdit()
        
        pass_layout.addRow("Дата начала действия*:", self.group_start_date_edit)
        pass_layout.addRow("Дата окончания действия:", self.group_end_date_edit)
        pass_layout.addRow("Цель посещения*:", self.group_purpose_input)
        pass_group.setLayout(pass_layout)
        layout.addWidget(pass_group)
        
        # Принимающая сторона
        host_group = QGroupBox("Принимающая сторона")
        host_layout = QFormLayout()
        
        self.group_department_combo = QComboBox()
        self.group_department_combo.addItems(self.departments)
        self.group_department_combo.currentIndexChanged.connect(self.update_group_employees_combo)
        
        self.group_employee_combo = QComboBox()
        self.update_group_employees_combo()
        
        host_layout.addRow("Подразделение*:", self.group_department_combo)
        host_layout.addRow("ФИО сотрудника*:", self.group_employee_combo)
        host_group.setLayout(host_layout)
        layout.addWidget(host_group)
        
        # Информация о посетителе
        visitor_group = QGroupBox("Информация о посетителе")
        visitor_layout = QFormLayout()
        
        self.group_last_name_input = QLineEdit()
        self.group_first_name_input = QLineEdit()
        self.group_middle_name_input = QLineEdit()
        self.group_phone_input = QLineEdit()
        self.group_phone_input.setInputMask("+7 (999) 999-99-99;_")
        self.group_email_input = QLineEdit()
        self.group_organization_input = QLineEdit()
        self.group_note_input = QLineEdit()
        self.group_birth_date_edit = QDateEdit()
        self.group_birth_date_edit.setMaximumDate(QDate.currentDate().addYears(-16))
        self.group_birth_date_edit.setCalendarPopup(True)
        self.group_passport_series_input = QLineEdit()
        self.group_passport_series_input.setMaxLength(4)
        self.group_passport_number_input = QLineEdit()
        self.group_passport_number_input.setMaxLength(6)
        
        visitor_layout.addRow("Фамилия*:", self.group_last_name_input)
        visitor_layout.addRow("Имя*:", self.group_first_name_input)
        visitor_layout.addRow("Отчество:", self.group_middle_name_input)
        visitor_layout.addRow("Телефон:", self.group_phone_input)
        visitor_layout.addRow("Email*:", self.group_email_input)
        visitor_layout.addRow("Организация:", self.group_organization_input)
        visitor_layout.addRow("Примечание*:", self.group_note_input)
        visitor_layout.addRow("Дата рождения*:", self.group_birth_date_edit)
        visitor_layout.addRow("Серия паспорта*:", self.group_passport_series_input)
        visitor_layout.addRow("Номер паспорта*:", self.group_passport_number_input)
        visitor_group.setLayout(visitor_layout)
        layout.addWidget(visitor_group)
        
        # Документы
        docs_group = QGroupBox("Прикрепляемые документы")
        docs_layout = QVBoxLayout()
        
        self.group_passport_scan_button = QPushButton("Скан паспорта*")
        self.group_passport_scan_button.clicked.connect(lambda: self.select_file("group_passport"))
        self.group_passport_scan_path = ""
        
        docs_layout.addWidget(self.group_passport_scan_button)
        docs_group.setLayout(docs_layout)
        layout.addWidget(docs_group)
        
        return form
    
    def load_employees(self):
        """Загружает список сотрудников из файла"""
        if not os.path.exists('employees.json'):
            return []
        
        with open('employees.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def get_departments(self):
        """Возвращает список уникальных подразделений"""
        departments = set()
        for employee in self.employees:
            if "position" in employee:
                # Предполагаем, что должность содержит название подразделения
                dept = employee["position"].split('-')[0].strip()
                departments.add(dept)
        return sorted(departments)
    
    def update_employees_combo(self):
        """Обновляет список сотрудников в комбобоксе"""
        department = self.department_combo.currentText()
        self.employee_combo.clear()
        
        for employee in self.employees:
            if "position" in employee and department in employee["position"]:
                self.employee_combo.addItem(employee["fio"])
    
    def update_group_employees_combo(self):
        """Обновляет список сотрудников в групповой форме"""
        department = self.group_department_combo.currentText()
        self.group_employee_combo.clear()
        
        for employee in self.employees:
            if "position" in employee and department in employee["position"]:
                self.group_employee_combo.addItem(employee["fio"])
    
    def switch_form(self):
        """Переключает между индивидуальной и групповой формами"""
        if self.individual_radio.isChecked():
            self.stacked_widget.setCurrentIndex(0)
        else:
            self.stacked_widget.setCurrentIndex(1)
    
    def select_file(self, file_type):
        """Выбор файла для загрузки"""
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(
            self, 
            "Выберите файл", 
            "", 
            "Images (*.png *.jpg *.jpeg);;PDF (*.pdf)"
        )
        
        if file_path:
            file_size = os.path.getsize(file_path) / (1024 * 1024)  # в МБ
            
            if file_type == "photo" and file_size > 4:
                QMessageBox.warning(self, "Ошибка", "Размер фотографии не должен превышать 4 МБ!")
                return
            elif file_type in ["passport", "group_passport"] and file_size > 10:
                QMessageBox.warning(self, "Ошибка", "Размер скана паспорта не должен превышать 10 МБ!")
                return
            
            if file_type == "photo":
                self.photo_path = file_path
                QMessageBox.information(self, "Успех", "Фотография выбрана!")
            elif file_type == "passport":
                self.passport_scan_path = file_path
                QMessageBox.information(self, "Успех", "Скан паспорта выбран!")
            elif file_type == "group_passport":
                self.group_passport_scan_path = file_path
                QMessageBox.information(self, "Успех", "Скан паспорта выбран!")
    
    def validate_email(self, email):
        """Проверяет валидность email"""
        pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
        return re.match(pattern, email) is not None
    
    def validate_individual_form(self):
        """Проверяет валидность индивидуальной формы"""
        errors = []
        
        # Проверка дат
        if self.start_date_edit.date() > self.end_date_edit.date():
            errors.append("Дата окончания не может быть раньше даты начала")
        
        # Проверка обязательных полей
        if not self.purpose_input.text().strip():
            errors.append("Цель посещения обязательна для заполнения")
        
        if not self.last_name_input.text().strip():
            errors.append("Фамилия обязательна для заполнения")
        
        if not self.first_name_input.text().strip():
            errors.append("Имя обязательно для заполнения")
        
        if not self.email_input.text().strip():
            errors.append("Email обязателен для заполнения")
        elif not self.validate_email(self.email_input.text().strip()):
            errors.append("Некорректный формат email")
        
        if not self.passport_series_input.text().strip() or len(self.passport_series_input.text()) != 4:
            errors.append("Серия паспорта должна состоять из 4 цифр")
        
        if not self.passport_number_input.text().strip() or len(self.passport_number_input.text()) != 6:
            errors.append("Номер паспорта должен состоять из 6 цифр")
        
        if not self.passport_scan_path:
            errors.append("Скан паспорта обязателен для прикрепления")
        
        if errors:
            QMessageBox.warning(self, "Ошибка", "\n".join(errors))
            return False
        
        return True
    
    def validate_group_form(self):
        """Проверяет валидность групповой формы"""
        errors = []
        
        # Проверка дат
        if self.group_start_date_edit.date() > self.group_end_date_edit.date():
            errors.append("Дата окончания не может быть раньше даты начала")
        
        # Проверка обязательных полей
        if not self.group_purpose_input.text().strip():
            errors.append("Цель посещения обязательна для заполнения")
        
        if not self.group_last_name_input.text().strip():
            errors.append("Фамилия обязательна для заполнения")
        
        if not self.group_first_name_input.text().strip():
            errors.append("Имя обязательно для заполнения")
        
        if not self.group_email_input.text().strip():
            errors.append("Email обязателен для заполнения")
        elif not self.validate_email(self.group_email_input.text().strip()):
            errors.append("Некорректный формат email")
        
        if not self.group_note_input.text().strip():
            errors.append("Примечание обязательно для заполнения")
        
        if not self.group_passport_series_input.text().strip() or len(self.group_passport_series_input.text()) != 4:
            errors.append("Серия паспорта должна состоять из 4 цифр")
        
        if not self.group_passport_number_input.text().strip() or len(self.group_passport_number_input.text()) != 6:
            errors.append("Номер паспорта должен состоять из 6 цифр")
        
        if not self.group_passport_scan_path:
            errors.append("Скан паспорта обязателен для прикрепления")
        
        if errors:
            QMessageBox.warning(self, "Ошибка", "\n".join(errors))
            return False
        
        return True
    
    def submit_request(self):
        """Отправляет заявку на пропуск"""
        if self.individual_radio.isChecked():
            if not self.validate_individual_form():
                return
            
            # Создаем заявку
            request = {
                "type": "individual",
                "dates": {
                    "start": self.start_date_edit.date().toString("yyyy-MM-dd"),
                    "end": self.end_date_edit.date().toString("yyyy-MM-dd")
                },
                "purpose": self.purpose_input.text().strip(),
                "host": {
                    "department": self.department_combo.currentText(),
                    "employee": self.employee_combo.currentText()
                },
                "visitor": {
                    "last_name": self.last_name_input.text().strip(),
                    "first_name": self.first_name_input.text().strip(),
                    "middle_name": self.middle_name_input.text().strip(),
                    "phone": self.phone_input.text().strip(),
                    "email": self.email_input.text().strip(),
                    "organization": self.organization_input.text().strip(),
                    "birth_date": self.birth_date_edit.date().toString("yyyy-MM-dd"),
                    "passport": {
                        "series": self.passport_series_input.text().strip(),
                        "number": self.passport_number_input.text().strip()
                    }
                },
                "documents": {
                    "photo": self.photo_path,
                    "passport_scan": self.passport_scan_path
                },
                "created_by": self.user_fullname,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "status": "pending"
            }
        else:
            if not self.validate_group_form():
                return
            
            # Создаем заявку
            request = {
                "type": "group",
                "dates": {
                    "start": self.group_start_date_edit.date().toString("yyyy-MM-dd"),
                    "end": self.group_end_date_edit.date().toString("yyyy-MM-dd")
                },
                "purpose": self.group_purpose_input.text().strip(),
                "host": {
                    "department": self.group_department_combo.currentText(),
                    "employee": self.group_employee_combo.currentText()
                },
                "visitor": {
                    "last_name": self.group_last_name_input.text().strip(),
                    "first_name": self.group_first_name_input.text().strip(),
                    "middle_name": self.group_middle_name_input.text().strip(),
                    "phone": self.group_phone_input.text().strip(),
                    "email": self.group_email_input.text().strip(),
                    "organization": self.group_organization_input.text().strip(),
                    "note": self.group_note_input.text().strip(),
                    "birth_date": self.group_birth_date_edit.date().toString("yyyy-MM-dd"),
                    "passport": {
                        "series": self.group_passport_series_input.text().strip(),
                        "number": self.group_passport_number_input.text().strip()
                    }
                },
                "documents": {
                    "passport_scan": self.group_passport_scan_path
                },
                "created_by": self.user_fullname,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "status": "pending"
            }
        
        # Сохраняем заявку
        self.save_request(request)
        QMessageBox.information(self, "Успех", "Заявка успешно отправлена!")
        self.clear_form()
    
    def save_request(self, request):
        """Сохраняет заявку в файл"""
        requests_file = "pass_requests.json"
        requests = []
        
        if os.path.exists(requests_file):
            with open(requests_file, 'r', encoding='utf-8') as f:
                requests = json.load(f)
        
        requests.append(request)
        
        with open(requests_file, 'w', encoding='utf-8') as f:
            json.dump(requests, f, ensure_ascii=False, indent=4)
    
    def clear_form(self):
        """Очищает форму"""
        if self.individual_radio.isChecked():
            self.start_date_edit.setDate(QDate.currentDate().addDays(1))
            self.end_date_edit.setDate(QDate.currentDate().addDays(1))
            self.purpose_input.clear()
            self.last_name_input.clear()
            self.first_name_input.clear()
            self.middle_name_input.clear()
            self.phone_input.clear()
            self.email_input.clear()
            self.organization_input.clear()
            self.birth_date_edit.setDate(QDate.currentDate().addYears(-30))
            self.passport_series_input.clear()
            self.passport_number_input.clear()
            self.photo_path = ""
            self.passport_scan_path = ""
        else:
            self.group_start_date_edit.setDate(QDate.currentDate().addDays(1))
            self.group_end_date_edit.setDate(QDate.currentDate().addDays(1))
            self.group_purpose_input.clear()
            self.group_last_name_input.clear()
            self.group_first_name_input.clear()
            self.group_middle_name_input.clear()
            self.group_phone_input.clear()
            self.group_email_input.clear()
            self.group_organization_input.clear()
            self.group_note_input.clear()
            self.group_birth_date_edit.setDate(QDate.currentDate().addYears(-30))
            self.group_passport_series_input.clear()
            self.group_passport_number_input.clear()
            self.group_passport_scan_path = ""

    def closeEvent(self, event):
        """При закрытии окна пропусков закрываем и эмулятор"""
        if hasattr(self, 'traffic_emulator'):
            self.traffic_emulator.close()
            event.accept()