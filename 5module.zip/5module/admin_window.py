from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QComboBox, QPushButton, QFileDialog, QMessageBox)
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
import json
import os
from datetime import datetime

class AdminWindow(QMainWindow):
    def __init__(self, user_fullname):
        super().__init__()
        self.user_fullname = user_fullname
        self.setWindowTitle("Стражник – Управление доступом")
        self.setFixedSize(800, 600)
        
        # Центральный виджет
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Основной layout
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)
        
        # Заголовок с информацией о пользователе
        header_layout = QHBoxLayout()
        title_label = QLabel("Управление доступом")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold;")
        
        user_label = QLabel(f"Пользователь: {user_fullname}")
        user_label.setStyleSheet("font-style: italic;")
        
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        header_layout.addWidget(user_label)
        main_layout.addLayout(header_layout)
        
        # Разделительная линия
        line = QLabel()
        line.setFrameShape(QLabel.HLine)
        line.setFrameShadow(QLabel.Sunken)
        main_layout.addWidget(line)
        
        # Форма для ввода данных
        form_layout = QVBoxLayout()
        
        # ФИО
        self.fio_label = QLabel("ФИО сотрудника*")
        self.fio_input = QLineEdit()
        form_layout.addWidget(self.fio_label)
        form_layout.addWidget(self.fio_input)
        
        # Пол
        self.gender_label = QLabel("Пол*")
        self.gender_combo = QComboBox()
        self.gender_combo.addItems(["Мужской", "Женский"])
        form_layout.addWidget(self.gender_label)
        form_layout.addWidget(self.gender_combo)
        
        # Должность
        self.position_label = QLabel("Должность*")
        self.position_input = QLineEdit()
        form_layout.addWidget(self.position_label)
        form_layout.addWidget(self.position_input)
        
        # Фотография
        self.photo_label = QLabel("Фотография сотрудника")
        self.photo_path = ""
        
        self.photo_preview = QLabel()
        self.photo_preview.setFixedSize(150, 200)
        self.photo_preview.setStyleSheet("border: 1px solid #ccc; background-color: #f5f5f5;")
        self.photo_preview.setAlignment(Qt.AlignCenter)
        self.photo_preview.setText("Фото не выбрано")
        
        self.photo_button = QPushButton("Выбрать фото")
        self.photo_button.clicked.connect(self.select_photo)
        
        photo_layout = QHBoxLayout()
        photo_layout.addWidget(self.photo_preview)
        photo_layout.addWidget(self.photo_button)
        
        form_layout.addWidget(self.photo_label)
        form_layout.addLayout(photo_layout)
        
        main_layout.addLayout(form_layout)
        
        # Кнопки
        buttons_layout = QHBoxLayout()
        self.save_button = QPushButton("Сохранить")
        self.save_button.clicked.connect(self.save_data)
        self.save_button.setStyleSheet("background-color: #4CAF50; color: white;")
        
        self.clear_button = QPushButton("Очистить")
        self.clear_button.clicked.connect(self.clear_form)
        self.clear_button.setStyleSheet("background-color: #f44336; color: white;")
        
        buttons_layout.addWidget(self.save_button)
        buttons_layout.addWidget(self.clear_button)
        main_layout.addLayout(buttons_layout)
        
        # Загрузка данных сотрудников
        self.employees_file = "employees.json"
        self.employees = self.load_employees()
        
    def load_employees(self):
        """Загружает список сотрудников из файла"""
        if not os.path.exists(self.employees_file):
            return []
        
        with open(self.employees_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def save_employees(self):
        """Сохраняет список сотрудников в файл"""
        with open(self.employees_file, 'w', encoding='utf-8') as f:
            json.dump(self.employees, f, ensure_ascii=False, indent=4)
    
    def select_photo(self):
        """Выбор фотографии сотрудника"""
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(
            self, 
            "Выберите фотографию", 
            "", 
            "Images (*.png *.jpg *.jpeg)"
        )
        
        if file_path:
            # Проверка размера файла (не более 2 МБ)
            file_size = os.path.getsize(file_path) / (1024 * 1024)  # в МБ
            if file_size > 2:
                QMessageBox.warning(self, "Ошибка", "Размер изображения не должен превышать 2 МБ!")
                return
            
            # Проверка соотношения сторон (примерная проверка)
            pixmap = QPixmap(file_path)
            width = pixmap.width()
            height = pixmap.height()
            
            # Примерная проверка соотношения 3:4 (допустим погрешность 10%)
            target_ratio = 3/4
            actual_ratio = width/height
            if not (0.9 * target_ratio <= actual_ratio <= 1.1 * target_ratio):
                QMessageBox.warning(
                    self, 
                    "Ошибка", 
                    "Соотношение сторон изображения должно быть примерно 3:4 (вертикальное фото)!"
                )
                return
            
            self.photo_path = file_path
            self.photo_preview.setPixmap(pixmap.scaled(
                150, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation
            ))
    
    def validate_form(self):
        """Проверяет корректность заполнения формы"""
        errors = []
        
        if not self.fio_input.text().strip():
            errors.append("ФИО сотрудника обязательно для заполнения")
        
        if not self.position_input.text().strip():
            errors.append("Должность обязательна для заполнения")
        
        # Проверка ФИО (должно содержать 3 слова)
        fio_parts = self.fio_input.text().strip().split()
        if len(fio_parts) != 3:
            errors.append("ФИО должно состоять из трёх частей (Фамилия Имя Отчество)")
        
        if errors:
            QMessageBox.warning(self, "Ошибка", "\n".join(errors))
            return False
        
        return True
    
    def save_data(self):
        """Сохраняет данные сотрудника"""
        if not self.validate_form():
            return
        
        # Создаем имя файла для фото (если оно выбрано)
        photo_filename = ""
        if self.photo_path:
            # Создаем папку для фото, если её нет
            if not os.path.exists("photos"):
                os.makedirs("photos")
            
            # Генерируем уникальное имя файла
            fio_parts = self.fio_input.text().strip().split()
            surname = fio_parts[0]
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            ext = os.path.splitext(self.photo_path)[1]
            photo_filename = f"photos/{surname}_{timestamp}{ext}"
            
            # Копируем фото
            import shutil
            shutil.copy2(self.photo_path, photo_filename)
        
        # Создаем запись сотрудника
        employee = {
            "fio": self.fio_input.text().strip(),
            "gender": self.gender_combo.currentText(),
            "position": self.position_input.text().strip(),
            "photo": photo_filename,
            "added_by": self.user_fullname,
            "added_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        # Добавляем в список и сохраняем
        self.employees.append(employee)
        self.save_employees()
        
        QMessageBox.information(self, "Успех", "Данные сотрудника успешно сохранены!")
        self.clear_form()
    
    def clear_form(self):
        """Очищает форму"""
        self.fio_input.clear()
        self.gender_combo.setCurrentIndex(0)
        self.position_input.clear()
        self.photo_path = ""
        self.photo_preview.clear()
        self.photo_preview.setText("Фото не выбрано")